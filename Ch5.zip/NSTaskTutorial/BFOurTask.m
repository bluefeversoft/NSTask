//
//  BFOurTask.m
//  NSTaskTutorial
//
//  Created by ScreenCast on 10/3/13.
//  Copyright (c) 2013 BlueFever. All rights reserved.
//

#import "BFOurTask.h"


@implementation BFOurTask {
	NSTask *task;
	id <BFTaskOutputProtocol> delegate;
}

-(void)SetResponseDelegate:(id<BFTaskOutputProtocol>)theDelegate {
	delegate = theDelegate;
}

-(void)SendCommand:(NSString*)command {
	
	NSString *eofCommand = [NSString stringWithFormat:@"%@\n",command];
	NSData *data = [eofCommand dataUsingEncoding:NSUTF8StringEncoding];
	[[[task standardInput] fileHandleForWriting] writeData:data];
	NSLog(@"Command Written:%@",command);
}



-(void)StartTask {
	task = [[NSTask alloc] init];
	[task setLaunchPath:@"/Users/taciturn_lemon/Documents/Temp/rep"];
	[task setArguments:@[]];
	
	[task setStandardOutput:[NSPipe new]];
	[task setStandardError:[task standardOutput]];
	[task setStandardInput:[NSPipe new]];
	
	[task launch];
	
	NSNotificationCenter *notificationCenter = [NSNotificationCenter defaultCenter];
	[notificationCenter addObserver:self
                           selector:@selector(getReadData:)
                               name:NSFileHandleReadCompletionNotification
                             object:[[task standardOutput] fileHandleForReading]];
	
	[[[task standardOutput] fileHandleForReading] readInBackgroundAndNotify];
	
	[notificationCenter addObserver:self
                           selector:@selector(QuitTask:)
                               name:NSTaskDidTerminateNotification
                             object:task];
	
	
}

- (void) getReadData: (NSNotification *)aNotification {
	
	NSData *data = [[aNotification userInfo] objectForKey:@"NSFileHandleNotificationDataItem"];
	NSString *response = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
	
	[delegate ReadInResponse:response];
	
	[[aNotification object] readInBackgroundAndNotify];
	
}


-(void)QuitTask:(NSNotification*)note {
	
	[[NSNotificationCenter defaultCenter]
	 removeObserver:self
	 name:NSTaskDidTerminateNotification
	 object:task
	 ];
	[[NSNotificationCenter defaultCenter] removeObserver:self
		name:NSFileHandleReadCompletionNotification
	object:[[task standardOutput] fileHandleForReading]];
	task = nil;
	[delegate ReadInResponse:@"Task Quit"];
}





@end




















































