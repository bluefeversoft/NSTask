//
//  BFTaskOutputProtocol.h
//  NSTaskTutorial
//
//  Created by ScreenCast on 10/3/13.
//  Copyright (c) 2013 BlueFever. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol BFTaskOutputProtocol <NSObject>

-(void)ReadInResponse:(NSString*)response;

@end
