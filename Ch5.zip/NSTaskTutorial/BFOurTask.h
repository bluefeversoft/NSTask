//
//  BFOurTask.h
//  NSTaskTutorial
//
//  Created by ScreenCast on 10/3/13.
//  Copyright (c) 2013 BlueFever. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BFTaskOutputProtocol.h"

@interface BFOurTask : NSObject

-(void)SendCommand:(NSString*)command;
-(void)StartTask;
-(void)SetResponseDelegate:(id<BFTaskOutputProtocol>)theDelegate;

@end
