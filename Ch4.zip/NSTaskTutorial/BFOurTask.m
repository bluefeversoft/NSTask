//
//  BFOurTask.m
//  NSTaskTutorial
//
//  Created by ScreenCast on 10/3/13.
//  Copyright (c) 2013 BlueFever. All rights reserved.
//

#import "BFOurTask.h"


@implementation BFOurTask {
	NSTask *task;
	id <BFTaskOutputProtocol> delegate;
}

-(void)SetResponseDelegate:(id<BFTaskOutputProtocol>)theDelegate {
	delegate = theDelegate;
}

-(void)SendCommand:(NSString*)command {
	
	NSString *eofCommand = [NSString stringWithFormat:@"%@\n",command];
	NSData *data = [eofCommand dataUsingEncoding:NSUTF8StringEncoding];
	[[[task standardInput] fileHandleForWriting] writeData:data];
	NSLog(@"Command Written:%@",command);
}



-(void)StartTask {
	task = [[NSTask alloc] init];
	[task setLaunchPath:@"/Users/taciturn_lemon/Documents/Temp/rep"];
	[task setArguments:@[]];
	
	[task setStandardOutput:[NSPipe new]];
	[task setStandardError:[task standardOutput]];
	[task setStandardInput:[NSPipe new]];
	
	[task launch];
}

@end











































