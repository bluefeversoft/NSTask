//
//  BFAppDelegate.m
//  NSTaskTutorial
//
//  Created by ScreenCast on 10/3/13.
//  Copyright (c) 2013 BlueFever. All rights reserved.
//

#import "BFAppDelegate.h"
#import "BFOurTask.h"

@implementation BFAppDelegate {
	BFOurTask *theTask;
}

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification
{
	// Insert code here to initialize your application
	theTask = [[BFOurTask alloc] init];
	[theTask SetResponseDelegate:self];
}

- (IBAction)ibaStartTask:(id)sender {
	[theTask StartTask];
}

- (IBAction)ibaSendCommand:(id)sender {
	NSString *command = [self.iboCommandText stringValue];
	[theTask SendCommand:command];
}

-(void)ReadInResponse:(NSString *)response {
	
}

@end


















