//
//  BFAppDelegate.h
//  NSTaskTutorial
//
//  Created by ScreenCast on 10/3/13.
//  Copyright (c) 2013 BlueFever. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "BFTaskOutputProtocol.h"

@interface BFAppDelegate : NSObject <NSApplicationDelegate, BFTaskOutputProtocol>

@property (assign) IBOutlet NSWindow *window;

- (IBAction)ibaStartTask:(id)sender;
- (IBAction)ibaSendCommand:(id)sender;


@property (weak) IBOutlet NSTextField *iboCommandText;
@property (unsafe_unretained) IBOutlet NSTextView *iboTaskOutput;







@end
