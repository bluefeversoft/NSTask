//
//  BFAppDelegate.m
//  NSTaskTutorial
//
//  Created by ScreenCast on 10/3/13.
//  Copyright (c) 2013 BlueFever. All rights reserved.
//

#import "BFAppDelegate.h"

@implementation BFAppDelegate

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification
{
	// Insert code here to initialize your application
}

- (IBAction)ibaStartTask:(id)sender {
}

- (IBAction)ibaSendCommand:(id)sender {
}
@end
